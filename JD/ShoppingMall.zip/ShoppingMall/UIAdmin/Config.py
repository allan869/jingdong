#!/usr/bin/env python
# -*- coding:utf-8 -*-

base_template_path = 'Admin'