#!/usr/bin/env python
# -*- coding:utf-8 -*-


def null_method(self):
    return 'UIMethod'