#!/usr/bin/env python
# -*- coding:utf-8 -*-

from .BaseSession import BaseSession


class MemcacheSession(BaseSession):

    def __init__(self,):
        pass

    def initialize(self, handler, expires):
        pass