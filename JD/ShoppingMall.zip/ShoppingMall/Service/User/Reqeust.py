#!/usr/bin/env python
# -*- coding:utf-8 -*-


class UserRequest:

    def __init__(self, username, email, password):
        self.username = username
        self.email = email
        self.password = password